package ex1;
import java.util.*;

public class Lab603 {
	static Scanner scan = new Scanner(System.in);
	static int[] numberofInteger = {78, 36, 58, 41, 25, 92, 75};

	public static void main(String[] args) {
		System.out.print("Input index of array : ");
		int IndexOfArray = scan.nextInt();
		while (indexOfArray < 0 || indexOfArray >(numberofInteger(numberofInteger.length - 1)) {
		

	}

}
