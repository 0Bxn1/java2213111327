package ex1;
import javax.swing.*;

public class Lab606 {

	public static void main(String[] args) {
		int[] nums = {25,78,41,22,36,85,37};
		String index = JOptionPane.showInputDialog("Input index of array:");
		
		
		
	}

}
