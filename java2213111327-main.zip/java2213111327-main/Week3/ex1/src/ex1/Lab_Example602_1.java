package ex1;
import javax.swing.*;

public class Lab_Example602_1 {

	public static void main(String[] args) {
		public static void main(String[] args) {
			int[] validValues = { 101, 108, 201, 213, 266, 304, 311, 409, 411, 412 };
			double[] price = { 0.89, 1.23, 3.50, 0.69, 5.79, 3.19, 0.99, 0.89, 1.26, 8.00 };
			static double[] itemPrice = 0;
			boolean validItem = false ;
			static int validOrder ;
			
			public static void main(Static[] args) {
				inputItem = Integer.parseInt(JOptionPane.showInputDialog("Enter item number to order"));
				if(checkItem(itemOrder)) {
					System.out.println("Item"+);
				}
			}

	}

}
