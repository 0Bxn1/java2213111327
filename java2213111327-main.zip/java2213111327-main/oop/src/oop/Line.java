package oop;

public class Line {
	
	public static void line() {
		for(int i = 0 ; i< 50;i++) {
			System.out.print("-");
		}
		System.out.println();
	}

}
